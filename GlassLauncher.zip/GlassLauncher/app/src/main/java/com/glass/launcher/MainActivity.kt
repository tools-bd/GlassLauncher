package com.glass.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    private var reload by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { GlassLauncher(reload) }
    }

    override fun onResume() {
        super.onResume()
        reload++ // refresh app list (new installs / uninstalls)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) closeDrawerSignal++
    }

    companion object { var closeDrawerSignal by mutableIntStateOf(0) }

    fun setBlur(radius: Int) {
        if (Build.VERSION.SDK_INT >= 31) window.setBackgroundBlurRadius(radius)
    }
}

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppItem(
                it.loadLabel(pm).toString(),
                it.activityInfo.packageName,
                it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}

private fun launch(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

private val glassShape = RoundedCornerShape(20.dp)

@Composable
fun GlassIcon(app: AppItem, size: androidx.compose.ui.unit.Dp = 60.dp) {
    Box(
        Modifier
            .size(size)
            .clip(glassShape)
            .background(
                Brush.linearGradient(listOf(Color.White.copy(0.38f), Color.White.copy(0.08f)))
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.9f), Color.White.copy(0.1f))),
                glassShape
            ),
        contentAlignment = Alignment.Center
    ) {
        // soft top highlight (liquid glass sheen)
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(size / 2)
                .background(
                    Brush.verticalGradient(listOf(Color.White.copy(0.35f), Color.Transparent))
                )
        )
        Image(app.icon, app.label, Modifier.size(size * 0.62f))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(app: AppItem, showLabel: Boolean = true, onLaunched: () -> Unit = {}) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box {
        Column(
            Modifier
                .padding(6.dp)
                .combinedClickable(
                    onClick = { launch(ctx, app.pkg); onLaunched() },
                    onLongClick = { menu = true }
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GlassIcon(app)
            if (showLabel) {
                Spacer(Modifier.height(4.dp))
                Text(
                    app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    modifier = Modifier.width(68.dp)
                )
            }
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            })
        }
    }
}

@Composable
fun GlassLauncher(reload: Int) {
    val ctx = LocalContext.current
    val activity = ctx as MainActivity
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var drawer by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }

    LaunchedEffect(reload) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    LaunchedEffect(MainActivity.closeDrawerSignal) { drawer = false; query = "" }
    LaunchedEffect(drawer) { activity.setBlur(if (drawer) 90 else 0) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            time = SimpleDateFormat("hh:mm", Locale.getDefault()).format(now)
            date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)
            delay(1000)
        }
    }
    BackHandler(drawer) { drawer = false; query = "" }

    val dock = apps.take(4)
    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = { if (total < -120f) drawer = true }
                )
            }
    ) {
        // ---- Home ----
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))
            Text(time, color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light)
            Text(date, color = Color.White.copy(0.85f), fontSize = 16.sp)
            Spacer(Modifier.weight(1f))
            Text("Swipe up", color = Color.White.copy(0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            // glass dock
            Row(
                Modifier
                    .clip(RoundedCornerShape(32.dp))
                    .background(Brush.verticalGradient(listOf(Color.White.copy(0.28f), Color.White.copy(0.10f))))
                    .border(1.dp, Color.White.copy(0.35f), RoundedCornerShape(32.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) { dock.forEach { AppCell(it, showLabel = false) } }
        }

        // ---- Drawer ----
        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically(spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow)) { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut()
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(if (Build.VERSION.SDK_INT >= 31) 0.25f else 0.6f))
                    .statusBarsPadding().navigationBarsPadding().imePadding()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(16.dp))
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(Brush.verticalGradient(listOf(Color.White.copy(0.30f), Color.White.copy(0.12f))))
                        .border(1.dp, Color.White.copy(0.4f), RoundedCornerShape(28.dp))
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    decorationBox = { inner ->
                        if (query.isEmpty()) Text("Search apps", color = Color.White.copy(0.6f))
                        inner()
                    }
                )
                Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.Center,
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filtered, key = { it.pkg }) {
                        AppCell(it, onLaunched = { drawer = false; query = "" })
                    }
                }
            }
        }
    }
}
